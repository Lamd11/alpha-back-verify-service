"""
Standalone utility modules that don't necessarily require the rest of Jawa to
function. Generally they can be copy-pasted into other projects for reuse.
"""